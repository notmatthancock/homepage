The filtered image, M = CIC^T, and the
image, I, itself are stored in the files, "filtered.txt"
and "image.txt". Column elements are separated by 
spaces, and rows are separated by new lines, e.g.,

1.23 2.34 3.45
7.00 8.01 9.12

M and I are size 2048 x 2048.

The parameters alpha_0, ... alpha_{2048-1} of the 
matrix, C, are stored in the file, "circulant.txt".
Elements of this vector are separated by newlines.
